<?php include_once '../views/header.php'?>

<div class="container px-4 px-lg-5 mt-5">
<div class="justify-content-center">
<h1>Lebuktam! <h2>Ezzel a résszel még nem vagyok kész!</h2></h1>
</div>
</div>


<?php include_once '../views/footer.php' ?>