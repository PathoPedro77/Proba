<?php include_once '../views/header.php' ?>
<section class="py-5" style="background-color:#323232;">
    <div class="text-center" style="color:white;"><h1>Jelenlegi könyveink</h1></div>
            <div class="container px-4 px-lg-5 mt-5">
                <div class="row gx-5 gx-lg-5 row-cols-5 row-cols-md-3 row-cols-xl-4 justify-content-center">
                    <div class="col mb-5">
                        <div class="card h-100">
                            <img class="card-img-top" src="https://www.madachkonyv.com/fotky32138/fotos/_vyr_12610cass.jpg" alt="..." />
                            <div class="card-body p-4" style="background-color: #222222;">
                                <div class="text-center">
                                    <h5 class="fw-bolder" style="color:white;">Végzet Ereklyéi - Csontváros</h5>
                                    <span class="prize" style="color:white;">3500Ft</span>
                                </div>
                            </div>
                            <div class="text-center"><a class="btn" href="#">Kosárba vele!</a></div>
                        </div>
                    </div>
                    <div class="col mb-5">
                        <div class="card h-100">
                            <img class="card-img-top" src="https://alexandra.hu/content/2021/11/Product/9789633997932.jpg" alt="..." />
                            <div class="card-body p-4" style="background-color: #222222;">
                                <div class="text-center">
                                    <h5 class="fw-bolder" style="color:white;">Végzet Ereklyéi - Hamuváros</h5>
                                    <<span class="prize" style="color:white;">3500Ft</span>
                                </div>
                            </div>
                                <div class="text-center"><a class="btn" href="#">Kosárba vele!</a>
                            </div>
                        </div>
                    </div>
                    <div class="col mb-5">
                        <div class="card h-100">
                            <img class="card-img-top" src="https://zonacomputers.hu/file/shop_image/product/139452101" alt="..." />
                            <div class="card-body p-4" style="background-color: #222222;">
                                <div class="text-center">
                                    <h5 class="fw-bolder" style="color:white;">Végzet Ereklyéi - Üvegváros</h5>
                                    <<span class="prize" style="color:white;">3500Ft</span>
                                </div>
                            </div>
                                <div class="text-center"><a class="btn" href="#">Kosárba vele!</a>
                            </div>
                        </div>
                    </div>
                    <div class="col mb-5">
                        <div class="card h-100">
                            <img class="card-img-top" src="https://book24.hu/img/boritok_cover/Konyvmolykepzo/a_vegzet_ereklyei_4bukott_angyalok_varosa_cover.jpg" alt="..." />
                            <div class="card-body p-4" style="background-color: #222222;">
                                <div class="text-center">
                                    <h5 class="fw-bolder" style="color:white;">Végzet Ereklyéi - Bukott angyalok városa</h5>
                                    <<span class="prize" style="color:white;">3500Ft</span>
                                </div>
                            </div>
                                <div class="text-center"><a class="btn" href="#">Kosárba vele!</a>
                            </div>
                        </div>
                    </div>
                    <div class="col mb-5">
                        <div class="card h-100">
                            <img class="card-img-top" src="https://www.konyvtunder.hu/images/big-preview/cassandra-clare-elveszett-lelkek-varosa--a-vegzet-ereklyei-5-uj-borito-218693.jpg" alt="..." />
                            <div class="card-body p-4" style="background-color: #222222;">
                                <div class="text-center">
                                    <h5 class="fw-bolder" style="color:white;">Végzet Ereklyéi - Elveszett lelkek városa</h5>
                                    <<span class="prize" style="color:white;">3500Ft</span>
                                </div>
                            </div>
                                <div class="text-center"><a class="btn" href="#">Kosárba vele!</a>
                            </div>
                        </div>
                    </div>
                    <div class="col mb-5">
                        <div class="card h-100">
                            <img class="card-img-top" src="https://www.konyvtunder.hu/images/big-preview/cassandra-clare-mennyei-tuz-varosa-a-vegzet-ereklyei-6-219215.jpg" alt="..." />
                            <div class="card-body p-4" style="background-color: #222222;">
                                <div class="text-center">
                                    <h5 class="fw-bolder" style="color:white;">Végzet Ereklyéi - Mennyei tűz városa</h5>
                                    <<span class="prize" style="color:white;">3500Ft</span>
                                </div>
                            </div>
                                <div class="text-center"><a class="btn" href="#">Kosárba vele!</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>   
                                
        </section>

<?php include_once '../views/footer.php' ?>