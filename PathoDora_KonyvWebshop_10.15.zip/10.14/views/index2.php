<?php include_once '../views/header.php' ?>
<div class="container px-4 px-lg-5 mt-5">
<div class="justify-content-center">
<h1>Jelenleg minden termékünk négyszer annyiba kerül, mint az eredeti ára. </h1>
<h2>Kérem, jöjjön vissza később!</h2>
</div>
</div>

<?php include_once '../views/footer.php' ?>