<?php require_once '../views/header.php'; ?>
<br><br>
<div class="container px-5 px-lg-2 mt-1">
<div class="row gx-5 gx-lg-5 row-cols-5 row-cols-md-3 row-cols-xl-4 justify-content-center">
<div class="col mb-5">
                        <div class="card h-20">
                            <div class="card-body p-4" style="background-color: #222222;">
                                <div class="text-center">
                                    <span class="prize" style="color:white;">Nincs még fiókod?</span>
                                </div>
                            </div>
                                <div class="text-center"><a class="btn" href="registration.php">Regisztrálj!</a>
                            </div>
                        </div>
                    </div>
                    <div class="col mb-5">
                        <div class="card h-20">
                            <div class="card-body p-4" style="background-color: #222222;">
                                <div class="text-center">
                                    <span class="prize" style="color:white;">Nem vagy bejelentkezve?</span>
                                </div>
                            </div>
                                <div class="text-center"><a class="btn" href="login.php">Jelentkezz be!</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <?php require_once '../views/footer.php'; ?>