<?php require_once '../views/header.php'; ?>

<br>
<div class="row">
    <div class="col-md-3"></div>
    <div class="col-md-6 col-sm-12">
        <div class="card">
            <div class="card-body">
                <h4 class="card-title">Kérem, regiaztráljon!</h4>
                <hr class="mb-3">
                <form method="POST" onsubmit="formValidate();" id="registerForm">
                    <div class="mb-3">
                        <label for="username" class="form-label">Adja meg a nevét:</label>
                        <input type="text" class="form-control" name="username" id="username" placeholder="Név" aria-describedby="helpId"
                            placeholder="" required <?php echo isset($_GET["username"]) ? 'value="'.$_GET["username"].'"' : ''; ?> 
                            style="<?php echo isset($_GET["error"]) && $_GET["error"] == "userExist" ? "border-color: red" : "" ?>"
                            />
                        <small id="helpId" class="form-text text-muted">
                            <?php echo isset($_GET["error"]) && $_GET["error"] == "userExist"  ? "A felhasználónév már foglalt" : "Used to log in to the system." ?>
                        </small>
                    </div>
                    <div class="mb-3">
                        <label for="password" class="form-label">Adja meg a jelszavát:</label>

                        <div id="passwordContainer">
                            <input type="password" placeholder="Jelszó" class="form-control" name="password" id="password"
                                aria-describedby="helpId" placeholder="" required onkeyup="validate(this)" />
                            <i class="fa-solid fa-eye" id="eye-icon" onclick="showContent('password', this)"></i>
                        </div>

                        <ul id="pwreq">
                            <li><small id="help_8" class="form-text text-muted">8 karakter hosszúság </small></li>
                            <li><small id="help_C" class="form-text text-muted">Nagy betű </small></li>
                            <li><small id="help_N" class="form-text text-muted">Kis betű </small></li>
                            <li><small id="help_S" class="form-text text-muted">Speciális karakter </small></li>
                            <li><small id="help_No" class="form-text text-muted">Szám </small></li>
                        </ul>
                    </div>
                    <div class="mb-3">
                        <label for="passwordConfirm" class="form-label">Jelszó jóváhagyása:</label>
                        <input type="password" class="form-control" placeholder="Jóváhagyás" name="passwordConfirm" id="passwordConfirm"
                            aria-describedby="helpId" placeholder="" required />
                        <small id="helpId" class="form-text text-muted">Kérem, hagyja jóvá a jelszavát!</small>
                    </div>
                    <div class="mb-3">
                        <label for="email" class="form-label">Adja meg az e-mail címét:</label>
                        <input type="email" class="form-control" placeholder="E-mail cím" name="email" id="email" aria-describedby="helpId"
                            placeholder="" required />
                        <small id="helpId" class="form-text text-muted">Kérem, adja meg az e-mail címét!</small>
                    </div>
                    <div class="mb-3 text-center">
                        <a href="index.php"><button class="btn" style="background-color: #323232; color:white;" name="submit" id="submit" type="submit">Regisztráció</button></a>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <div class="col-md-3"></div>
</div>

<script>


    let showContent = (id, eye) => {
        let input = document.getElementById(id);
        let hidden = input.getAttribute("type");

        if (hidden == "password") {
            input.setAttribute("type", "text");
            eye.setAttribute("class", "fa-solid fa-eye-slash");
        }
        else {
            input.setAttribute("type", "password");
            eye.setAttribute("class", "fa-solid fa-eye");
        }
    }

    let validate = (input) => {

        let password = input.value;
        let help_8 = document.getElementById("help_8");
        let help_C = document.getElementById("help_C");
        let help_N = document.getElementById("help_N");
        let help_S = document.getElementById("help_S");
        let help_No = document.getElementById("help_No");

        console.log(password.length);

        if ((password.length) >= 8) {
            help_8.setAttribute("class", "form-text text-muted");
            help_8.classList.add("text-success");
            help_8.classList.add("fw-bold");
            help_8.classList.remove("text-muted");

            if (document.getElementById("successCheck") == null) {
                help_8.innerHTML += '<i class="fa-regular fa-circle-check text-success" id="successCheck"></i>';
            }
        }
        else if ((password.length) < 8 && password.length > 0) {
            help_8.setAttribute("class", "form-text text-muted");
            help_8.classList.add("text-danger");
            help_8.classList.add("fw-bold");
            help_8.classList.remove("text-muted");

            if (document.getElementById("successCheck") != null) {
                document.getElementById("successCheck").remove();
            }
        }
        else {
            help_8.setAttribute("class", "form-text text-muted");

            if (document.getElementById("successCheck") != null) {
                document.getElementById("successCheck").remove();
            }
        }

        let pattern = /[A-Z]/;
        if (pattern.test(password)) {
            help_C.setAttribute("class", "form-text text-muted"); 
            help_C.classList.add("text-success");
            help_C.classList.add("fw-bold");
            help_C.classList.remove("text-muted");

            if (document.getElementById("successCheck_C") == null) {
                help_C.innerHTML += '<i class="fa-regular fa-circle-check text-success" id="successCheck_C"></i>';
            }
        }
        else if (password.length > 0) {
            help_C.setAttribute("class", "form-text text-muted");
            help_C.classList.add("text-danger");
            help_C.classList.add("fw-bold");
            help_C.classList.remove("text-muted");
            if (document.getElementById("successCheck_C") != null) {
                document.getElementById("successCheck_C").remove();
            }
        }
        else {
            help_C.setAttribute("class", "form-text text-muted");
            if (document.getElementById("successCheck_C") != null) {
                document.getElementById("successCheck_C").remove();
            }
        }

        pattern = /[a-z]/;
        if (pattern.test(password)) {
            help_N.setAttribute("class", "form-text text-muted"); 
            help_N.classList.add("text-success");
            help_N.classList.add("fw-bold");
            help_N.classList.remove("text-muted");

            if (document.getElementById("successCheck_N") == null) {
                help_N.innerHTML += '<i class="fa-regular fa-circle-check text-success" id="successCheck_N"></i>';
            }
        }
        else if (password.length > 0) {
            help_N.setAttribute("class", "form-text text-muted");
            help_N.classList.add("text-danger");
            help_N.classList.add("fw-bold");
            help_N.classList.remove("text-muted");
            if (document.getElementById("successCheck_N") != null) {
                document.getElementById("successCheck_N").remove();
            }
        }
        else {
            help_N.setAttribute("class", "form-text text-muted");
            if (document.getElementById("successCheck_N") != null) {
                document.getElementById("successCheck_N").remove();
            }
        }

        pattern = /[!%&@#]/;
        if (pattern.test(password)) {
            help_S.setAttribute("class", "form-text text-muted");
            help_S.classList.add("text-success");
            help_S.classList.add("fw-bold");
            help_S.classList.remove("text-muted");

            if (document.getElementById("successCheck_S") == null) {
                help_S.innerHTML += '<i class="fa-regular fa-circle-check text-success" id="successCheck_S"></i>';
            }
        }
        else if (password.length > 0) {
            help_S.setAttribute("class", "form-text text-muted");
            help_S.classList.add("text-danger");
            help_S.classList.add("fw-bold");
            help_S.classList.remove("text-muted");

            if (document.getElementById("successCheck_S") != null) {
                document.getElementById("successCheck_S").remove();
            }
        }
        else {
            help_S.setAttribute("class", "form-text text-muted");
            if (document.getElementById("successCheck_S") != null) {
                document.getElementById("successCheck_S").remove();
            }
        }

        pattern = /[0-9]/;
        if (pattern.test(password)) {
            help_No.setAttribute("class", "form-text text-muted");
            help_No.classList.add("text-success");
            help_No.classList.add("fw-bold");
            help_No.classList.remove("text-muted");

            if (document.getElementById("successCheck_No") == null) {
                help_No.innerHTML += '<i class="fa-regular fa-circle-check text-success" id="successCheck_No"></i>';
            }
        }
        else if (password.length > 0) {
            help_No.setAttribute("class", "form-text text-muted");
            help_No.classList.add("text-danger");
            help_No.classList.add("fw-bold");
            help_No.classList.remove("text-muted");
            if (document.getElementById("successCheck_No") != null) {
                document.getElementById("successCheck_No").remove();
            }
        }
        else {
            help_No.setAttribute("class", "form-text text-muted");
            if (document.getElementById("successCheck_No") != null) {
                document.getElementById("successCheck_No").remove();
            }
        }
    }

    let formValidate = () => {
        let hasError = false;

        password = document.getElementById("password");
        passwordConfirm = document.getElementById("passwordConfirm");

        console.log(password);
        console.log(passwordConfirm.value);
        
        
        if (password.value != passwordConfirm.value) {
            password.setAttribute("style", "border-color: red !important;");
            passwordConfirm.setAttribute("style", "border-color: red !important;");

            let span = document.createElement("span");
            span.innerHTML = "A két jelszó nem egyezik. <br>";
            span.setAttribute("class", "form-text text-muted");
            passwordConfirm.after(span);
            hasError = true;
        }
    }
</script>
<?php require_once '../views/footer.php'; ?>