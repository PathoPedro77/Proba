<?php include_once '../views/header.php' ?>

<br>
<div class="row">
    <div class="col-md-3"></div>
    <div class="col-md-6 col-sm-12">
        <div class="card">
            <div class="card-body">
            <h4 class="card-title">Bejelentkezés</h4>
            <hr class="mb-3">
                                <form action="login.php" method="POST">
                                <label for="username" class="form-label">Kérem, adja meg a felhasználónevét:</label>
                                    <input class="form-control mb-2" type="text" placeholder="Felhazsnálónév" name="login_username"
                                        id="login_username">
                                        <label for="password" class="form-label">Kérem, adja meg a jelszavát:</label>
                                    <input class="form-control mb-2" type="password" name="login_password"
                                        id="login_password">
                                    <div class="text-center">
                                        <button class="btn" style="background-color: #323232; color:white;" placeholder="Jelszó:" name="submit" type="submit"
                                            id="submit">Bejelentkezés</button>
                                    </div>
                                </form>
    <div class="col-md-3"></div>
</div>

 <?php
require '../database/database.php';

$username = mysqli_real_escape_string($connection, $_POST['login_username']);
$password = mysqli_real_escape_string($connection, $_POST['login_password']);

$user_query = 'SELECT * FROM users WHERE username = "' . $username . '";';
$result = mysqli_query($connection, $user_query);

if (mysqli_num_rows($result) != 1) {die('Nincs ilyen felhasználó, lehet elírtad a neved.');
}
else {
    $userData = mysqli_fetch_assoc($result);

    if (password_verify($password, trim($userData["password"])) == false) {
        die("Hibás jelszó");
    }
    else {

        session_start();
        
        echo 'Bejelentkezés sikeres!';
        $_SESSION["id"] = $userData["id"];
        $_SESSION["username"] = $userData["username"];
        $_SESSION["email"] = $userData["email"];

        header("../index.php?status=success");
    }
}
?>

<?php require_once '../views/footer.php'; ?>